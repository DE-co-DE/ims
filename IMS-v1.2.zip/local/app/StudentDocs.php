<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class StudentDocs extends Model {

	protected $table = 'student_docs';	
	
	
}
