<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class CourseBatch extends Model {

	protected $table = 'course_batch';	
	
	
}
